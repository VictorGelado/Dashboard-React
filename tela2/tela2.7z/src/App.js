import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <div>
          <p>&lt;</p>
          <i className="fas fa-chart-line"></i>
        </div>
        <h1>Ride</h1>

        <div className="dates">
          <div className="date">
            <p>26</p>
            <p>May</p>
          </div>
          <div className="date">
            <p>27</p>
            <p>May</p>
          </div>
          <div className="date-selected">
            <i className="fas fa-calendar-alt"></i>
            <div>
              <p>28</p>
              <p>May</p>
            </div>
          </div>
          <div className="date">
            <p>29</p>
            <p>May</p>
          </div>
          <div className="date">
            <p>30</p>
            <p>May</p>
          </div>
        </div>
      </header>
    </div>
  );
}

export default App;
